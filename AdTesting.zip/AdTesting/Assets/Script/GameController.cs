﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        AdmobAds.Instance.RequestBanner();
        //FacebookAds.Instance.LoadBanner();
    }

    public void LoadAM()
    {
        AdmobAds.Instance.RequestInterstitial();
        AdmobAds.Instance.RequstReward();
    }
    public void ShowInterstitialAdAM()
    {
        AdmobAds.Instance.ShowInterstitialAd();
    }
    public void ShowRewardAdAM()
    {
        AdmobAds.Instance.ShowRewardedAd();
    }


    public void LoadFB()
    {
        FacebookAds.Instance.LoadInterstitial();
        FacebookAds.Instance.LoadRewardedVideo();
    }
    public void ShowInterstitialAdFB()
    {
        FacebookAds.Instance.ShowInterstitial();
    }
    public void ShowRewardAdFB()
    {
        FacebookAds.Instance.ShowRewardedVideo();
    }
}
